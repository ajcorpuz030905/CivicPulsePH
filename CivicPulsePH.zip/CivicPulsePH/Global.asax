﻿<%@ Application Codebehind="Global.asax.cs" Inherits="CivicPulsePH.MvcApplication" Language="C#" %>
