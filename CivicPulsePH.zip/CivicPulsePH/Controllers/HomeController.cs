﻿
using System.Web.Mvc;

namespace CivicPulsePH.Controllers
{
    public class HomeController : Controller
    {
        // Homepage
        public ActionResult Index()
        {
            return View();
        }

        // Political turbulence research
        public ActionResult Background()
        {
            return View();
        }

        // Technology-based solutions
        public ActionResult Solutions()
        {
            return View();
        }

        // Credible research and references
        public ActionResult Resources()
        {
            return View();
        }

        // Interactive civic literacy quiz
        public ActionResult Quiz()
        {
            return View();
        }

        // Citizen feedback and participation
        public ActionResult Feedback()
        {
            return View();
        }

        // About the project
        public ActionResult About()
        {
            return View();
        }

        // Contact information
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Team()
        {
            return View();
        }

    }
}
